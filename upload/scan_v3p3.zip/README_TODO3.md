# TODO #3 — Minimal action path (physical_gap)

This checkpoint evaluates whether the 1D axis WKB action `S_z` is a good proxy for the **true minimal tunneling action** in 2D axisymmetric geometry.

## Methods (two independent proxies)

1. **Graph / eikonal (fast-marching proxy)**  
   Discretize the cropped (ρ,z) domain; define local cost  
   `c(ρ,z)=sqrt(max(U(ρ,z)-E,0))` (with a small threshold `tol` to enforce `c=0` in the allowed wells).  
   Compute the minimal accumulated cost between the left and right allowed components via Dijkstra on an 8-neighbor grid.

2. **Bezier relaxation (string/variational proxy)**  
   Constrain a family of curves with endpoints on the axis turning contour `U(0,z)=E`.  
   Use a 2-parameter Bezier profile ρ(t) with ρ(0)=ρ(1)=0; minimize  
   `S[ρ]=∫ sqrt(max(U(ρ,z)-E,0)) ds` over (ρ1,ρ2) via L-BFGS-B.

## Deliverables

- `todo3_Smin_table_physical_gap.csv` — **S_z vs S_min** for D=6,12,18.
- `todo3_scaling_fit.txt` — scaling of `(S_min/S_z-1)` vs `1/D`.
- `todo3_S_vs_D.png`, `todo3_relative_diff.png` — plots.
- `todo3_min_action_v3p3.py` — reproducibility script.

## Referee-grade readout (what this says)

- The Bezier minimizer yields **ρ1,ρ2 ~ few×10^-3**, i.e. the minimizing path stays essentially on-axis.
- The discrepancy `S_min - S_z` is **sub-percent** and decreases with D (roughly ~1/D), consistent with
  `S_z` growing approximately linearly with D while discretization biases remain ~O(10^-2) in absolute units.

Interpretation: at these representative points, there is **no evidence for an off-axis “escape route”** that materially reduces the tunneling action.
