#!/usr/bin/env python3
"""TODO #3 — Minimal action path check (physical_gap)

Computes S_min in 2D (rho,z) using:
  (A) Dijkstra on a weighted grid (fast-marching proxy)
  (B) 2-parameter Bezier variational path (string/relaxation proxy)

Inputs (expected in current directory):
  - U2D_physical_gap_D{D}.npy
  - U2D_physical_gap_grid_D{D}.npz
  - scan_axis1d_v3p1_physical_gap.csv

Outputs:
  - todo3_Smin_table_physical_gap.csv
  - todo3_scaling_fit.txt
  - todo3_S_vs_D.png
  - todo3_relative_diff.png
"""

import argparse, math
import numpy as np
import pandas as pd
from heapq import heappush, heappop
from scipy.interpolate import RegularGridInterpolator
from scipy.optimize import minimize
import matplotlib.pyplot as plt

def load_U2D(D):
    U = np.load(f"U2D_physical_gap_D{D}.npy").astype(np.float64)
    g = np.load(f"U2D_physical_gap_grid_D{D}.npz")
    rho = g["rho"].astype(np.float64)
    z = g["z"].astype(np.float64)
    return rho, z, U

def crop_and_downsample(rho, z, U, D, rho_max=8.0, z_margin=4.0, stride=2):
    zmin = -(D/2 + z_margin)
    zmax = +(D/2 + z_margin)
    ir = np.where(rho <= rho_max)[0]
    iz = np.where((z >= zmin) & (z <= zmax))[0]
    rho_c = rho[ir][::stride]
    z_c = z[iz][::stride]
    U_c = U[np.ix_(ir, iz)][::stride, ::stride]
    return rho_c, z_c, U_c

def nearest_idx(arr, val):
    return int(np.argmin(np.abs(arr - val)))

def turning_points_near_zero(Uaxis, z, E):
    y = Uaxis - E
    idx = np.where(np.sign(y[:-1]) != np.sign(y[1:]))[0]
    if len(idx) == 0:
        return None
    roots = []
    for k in idx:
        z0, z1 = z[k], z[k+1]
        y0, y1 = y[k], y[k+1]
        zr = z0 - y0 * (z1 - z0) / (y1 - y0)
        roots.append(zr)
    roots = np.array(sorted(roots))
    neg = roots[roots < 0.0]
    pos = roots[roots > 0.0]
    if len(neg) == 0 or len(pos) == 0:
        return None
    return float(neg[-1]), float(pos[0])

def connected_component_zero(cost_zero, start_idx):
    Nr, Nz = cost_zero.shape
    sr, sz = start_idx
    if not cost_zero[sr, sz]:
        return None
    stack = [(sr, sz)]
    vis = set([(sr, sz)])
    while stack:
        r, z = stack.pop()
        for dr, dz in [(1,0),(-1,0),(0,1),(0,-1)]:
            rr, zz = r + dr, z + dz
            if 0 <= rr < Nr and 0 <= zz < Nz and cost_zero[rr, zz] and (rr, zz) not in vis:
                vis.add((rr, zz))
                stack.append((rr, zz))
    return vis

def dijkstra_min_action(cost, drho, dz, left_set, right_set):
    Nr, Nz = cost.shape
    INF = 1e100
    dist = np.full((Nr, Nz), INF, dtype=np.float64)
    h = []
    for (r, z) in left_set:
        dist[r, z] = 0.0
        heappush(h, (0.0, r, z))

    neigh = [
        (1,0,drho),(-1,0,drho),(0,1,dz),(0,-1,dz),
        (1,1,math.hypot(drho,dz)),(1,-1,math.hypot(drho,dz)),
        (-1,1,math.hypot(drho,dz)),(-1,-1,math.hypot(drho,dz)),
    ]

    right_bool = np.zeros((Nr, Nz), dtype=bool)
    for r, z in right_set:
        right_bool[r, z] = True

    visited = np.zeros((Nr, Nz), dtype=bool)
    while h:
        d, r, z = heappop(h)
        if d != dist[r, z]:
            continue
        if right_bool[r, z]:
            return float(d)
        if visited[r, z]:
            continue
        visited[r, z] = True
        c0 = cost[r, z]
        for dr_, dz_, ds in neigh:
            rr, zz = r + dr_, z + dz_
            if 0 <= rr < Nr and 0 <= zz < Nz:
                nd = d + 0.5 * (c0 + cost[rr, zz]) * ds
                if nd < dist[rr, zz]:
                    dist[rr, zz] = nd
                    heappush(h, (nd, rr, zz))
    return float('nan')

def bezier_rho(t, rho1, rho2):
    return 3*rho1*t*(1-t)**2 + 3*rho2*(t**2)*(1-t)

def optimize_bezier(rho_c, z_c, U_c, D, E, tol=1e-4, rho_max=8.0, npts=1201):
    Uaxis = U_c[0, :]
    tp = turning_points_near_zero(Uaxis, z_c, E)
    if tp is None:
        raise RuntimeError('No axis turning points found.')
    z1, z2 = tp
    interp = RegularGridInterpolator((rho_c, z_c), U_c, bounds_error=False, fill_value=float(np.max(U_c)))
    t = np.linspace(0, 1, npts)

    def action(x):
        rho1, rho2 = x
        zline = z1 + t*(z2 - z1)
        rline = bezier_rho(t, rho1, rho2)
        Uv = interp(np.stack([rline, zline], axis=1))
        y = Uv - E
        y[y <= tol] = 0.0
        c = np.sqrt(np.clip(y, 0, None))
        ds = np.hypot(np.diff(zline), np.diff(rline))
        return float(np.sum(0.5*(c[:-1] + c[1:]) * ds))

    res = minimize(action, np.array([0.0, 0.0]), method='L-BFGS-B',
                   bounds=[(0.0, rho_max), (0.0, rho_max)],
                   options={'maxiter': 200, 'ftol': 1e-12})
    return res, tp

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--Ds', default='6,12,18')
    ap.add_argument('--rho_max', type=float, default=8.0)
    ap.add_argument('--z_margin', type=float, default=4.0)
    ap.add_argument('--stride', type=int, default=2)
    ap.add_argument('--tol', type=float, default=1e-4)
    args = ap.parse_args()

    Ds = [float(x) for x in args.Ds.split(',')]
    axis = pd.read_csv('scan_axis1d_v3p1_physical_gap.csv')
    axis = axis[(axis['n'] == 1) & (axis['D'].isin(Ds))].copy()

    rows = []
    for D in Ds:
        r = axis[axis['D'] == D].iloc[0]
        E = float(r['E'])
        S_z = float(r['S_z_physical'])

        rho, z, U = load_U2D(int(D))
        rho_c, z_c, U_c = crop_and_downsample(rho, z, U, D, rho_max=args.rho_max, z_margin=args.z_margin, stride=args.stride)

        y = U_c - E
        cost = np.sqrt(np.clip(y, 0, None))
        cost[y <= args.tol] = 0.0

        drho = float(rho_c[1] - rho_c[0])
        dz = float(z_c[1] - z_c[0])

        r0 = nearest_idx(rho_c, 0.0)
        zl = nearest_idx(z_c, -D/2)
        zr = nearest_idx(z_c, +D/2)
        zero = cost == 0.0
        left = connected_component_zero(zero, (r0, zl))
        right = connected_component_zero(zero, (r0, zr))
        S_min_dijkstra = dijkstra_min_action(cost, drho, dz, left, right)

        res, tp = optimize_bezier(rho_c, z_c, U_c, D, E, tol=args.tol, rho_max=args.rho_max)
        S_min_bezier = float(res.fun)

        rows.append({
            'D': D, 'E': E, 'S_z': S_z,
            'S_min_dijkstra': S_min_dijkstra,
            'S_min_bezier': S_min_bezier,
            'rho1': float(res.x[0]), 'rho2': float(res.x[1]),
            'tp_z1': float(tp[0]), 'tp_z2': float(tp[1]),
            'ratio_dijkstra': S_min_dijkstra / S_z,
            'ratio_bezier': S_min_bezier / S_z,
            'delta_dijkstra': S_min_dijkstra - S_z,
            'delta_bezier': S_min_bezier - S_z,
        })

    df = pd.DataFrame(rows).sort_values('D')
    df.to_csv('todo3_Smin_table_physical_gap.csv', index=False)

    plt.figure()
    plt.plot(df['D'], df['S_z'], marker='o', label='S_z (axis1d)')
    plt.plot(df['D'], df['S_min_dijkstra'], marker='o', label='S_min (dijkstra)')
    plt.plot(df['D'], df['S_min_bezier'], marker='o', label='S_min (bezier)')
    plt.xlabel('D'); plt.ylabel('Action S'); plt.legend(); plt.tight_layout()
    plt.savefig('todo3_S_vs_D.png', dpi=180)
    plt.close()

    plt.figure()
    plt.plot(df['D'], df['ratio_dijkstra'] - 1, marker='o', label='dijkstra')
    plt.plot(df['D'], df['ratio_bezier'] - 1, marker='o', label='bezier')
    plt.xlabel('D'); plt.ylabel('S_min/S_z - 1'); plt.legend(); plt.tight_layout()
    plt.savefig('todo3_relative_diff.png', dpi=180)
    plt.close()

if __name__ == '__main__':
    main()
