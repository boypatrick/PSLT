#!/usr/bin/env python3
"""
TODO #3A: stride=1 fine-grid convergence check for 2D minimal-action proxy.

Inputs (from scan_v3p3.zip or your working dir):
  - scan_axis1d_v3p1_physical_gap.csv
  - U2D_physical_gap_D{D}.npy
  - U2D_physical_gap_grid_D{D}.npz

We compute S_min via weighted shortest path on (rho,z) grid:
  cost = ∫ sqrt(max(U-E,0)) ds
with two neighborhood stencils (8 and 24 moves) to cross-check anisotropy.

We compare coarse grids (stride=2,4 subsampling) against fine (stride=1).
"""
import argparse, math, heapq, os
import numpy as np, pandas as pd

def nearest_idx(arr,val):
    return int(np.clip(np.searchsorted(arr,val),0,len(arr)-1))

def crop_barrier(rho,z,U,z1,z2,rho_max=2.0,zpad=0.2):
    ir=np.where(rho<=rho_max)[0]
    iz=np.where((z>=z1-zpad)&(z<=z2+zpad))[0]
    return rho[ir], z[iz], U[np.ix_(ir,iz)]

def subsample(rho,z,U,stride):
    return rho[::stride], z[::stride], U[::stride,::stride]

def make_neighbors(kind="8"):
    neigh=[]
    if kind=="8":
        neigh=[(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1)]
    elif kind=="24":
        neigh=[(-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1),
               (2,0),(-2,0),(0,2),(0,-2),
               (2,1),(2,-1),(-2,1),(-2,-1),
               (1,2),(-1,2),(1,-2),(-1,-2)]
    else:
        raise ValueError("neighbors must be 8 or 24")
    return neigh

def dijkstra_weighted(rho,z,U,E,start,goal,neigh):
    dr=float(rho[1]-rho[0]); dz=float(z[1]-z[0])
    w=np.sqrt(np.maximum(U-E,0.0)).astype(np.float64)
    si=nearest_idx(rho,start[0]); sj=nearest_idx(z,start[1])
    gi=nearest_idx(rho,goal[0]); gj=nearest_idx(z,goal[1])
    dist=np.full(U.shape, np.inf, dtype=np.float64)
    dist[si,sj]=0.0
    H=[(0.0,si,sj)]
    steps=[math.hypot(di*dr,dj*dz) for di,dj in neigh]
    while H:
        d,i,j=heapq.heappop(H)
        if d!=dist[i,j]: 
            continue
        if (i,j)==(gi,gj):
            break
        wi=w[i,j]
        for (di,dj),step in zip(neigh,steps):
            ii=i+di; jj=j+dj
            if 0<=ii<U.shape[0] and 0<=jj<U.shape[1]:
                nd=d+0.5*(wi+w[ii,jj])*step
                if nd<dist[ii,jj]:
                    dist[ii,jj]=nd
                    heapq.heappush(H,(nd,ii,jj))
    return float(dist[gi,gj])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--workdir", default=".", help="directory containing the input files")
    ap.add_argument("--Ds", default="6,12,18", help="comma-separated Ds")
    ap.add_argument("--rho_max", type=float, default=2.0)
    ap.add_argument("--zpad", type=float, default=0.2)
    ap.add_argument("--out_dir", default="todo3A_out")
    args=ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    Ds=[float(x) for x in args.Ds.split(",") if x.strip()]

    scan=pd.read_csv(os.path.join(args.workdir,"scan_axis1d_v3p1_physical_gap.csv"))
    rows=[]
    for D in Ds:
        row=scan[(scan.D==D)&(scan.n==1)].iloc[0]
        E=float(row.E); z1=float(row.z1); z2=float(row.z2)
        U=np.load(os.path.join(args.workdir,f"U2D_physical_gap_D{int(D)}.npy"))
        g=np.load(os.path.join(args.workdir,f"U2D_physical_gap_grid_D{int(D)}.npz"))
        rho=g["rho"]; z=g["z"]
        rho,z,U=crop_barrier(rho,z,U,z1,z2,rho_max=args.rho_max,zpad=args.zpad)
        for stride in [1,2,4]:
            rh,zz,UU=(rho,z,U) if stride==1 else subsample(rho,z,U,stride)
            for nk in ["8","24"]:
                neigh=make_neighbors(nk)
                S=dijkstra_weighted(rh,zz,UU,E,(0.0,z1),(0.0,z2),neigh)
                rows.append(dict(D=D,stride=stride,neighbors=nk,Smin=S,dr=float(rh[1]-rh[0]),dz=float(zz[1]-zz[0])))
    df=pd.DataFrame(rows)
    df.to_csv(os.path.join(args.out_dir,"todo3A_convergence_table.csv"), index=False)
    print("Wrote:", os.path.join(args.out_dir,"todo3A_convergence_table.csv"))

if __name__=="__main__":
    main()
