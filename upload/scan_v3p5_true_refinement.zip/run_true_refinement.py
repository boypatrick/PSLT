
import os, math, heapq
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def compute_U2D(rho, z, D, a, eps, m0, xi):
    R, Z = np.meshgrid(rho, z, indexing='ij')
    zp = Z - D/2.0
    zm = Z + D/2.0
    rp2 = R*R + zp*zp
    rm2 = R*R + zm*zm
    Omega = 1.0 + a*(1.0/np.sqrt(rp2 + eps*eps) + 1.0/np.sqrt(rm2 + eps*eps))
    lap_term = -3.0*(eps*eps)*((rp2 + eps*eps)**(-2.5) + (rm2 + eps*eps)**(-2.5))
    lap_Omega = a*lap_term
    U = (m0*m0)*(Omega*Omega - 1.0) + (1.0 - 6.0*xi)*(lap_Omega / Omega)
    return U.astype(np.float64)

def turning_points_axis(U_axis, z, E):
    f = U_axis - E
    s = np.sign(f)
    s[s==0]=1
    crossings=[]
    for i in range(len(z)-1):
        if s[i]*s[i+1] < 0:
            z0 = z[i] - f[i]*(z[i+1]-z[i])/(f[i+1]-f[i])
            crossings.append(z0)
    neg=[c for c in crossings if c<0]
    pos=[c for c in crossings if c>0]
    if not neg or not pos:
        return None, None
    return max(neg), min(pos)

def dijkstra_action(U, rho, z, E, start, goal, neighbors=8):
    if neighbors!=8:
        raise ValueError("This repro script uses neighbors=8 only.")
    offs=[(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]
    Nr,Nz = U.shape
    W = np.sqrt(np.maximum(U - E, 0.0))
    sr, sz = start
    gr, gz = goal
    dist = np.full((Nr,Nz), np.inf, dtype=np.float64)
    dist[sr,sz]=0.0
    hq=[(0.0,sr,sz)]
    while hq:
        d,i,j = heapq.heappop(hq)
        if d!=dist[i,j]:
            continue
        if (i,j)==(gr,gz):
            return float(d)
        for di,dj in offs:
            ni=i+di; nj=j+dj
            if ni<0 or ni>=Nr or nj<0 or nj>=Nz:
                continue
            ds = math.sqrt((rho[ni]-rho[i])**2 + (z[nj]-z[j])**2)
            cost = 0.5*(W[i,j]+W[ni,nj])*ds
            nd = d + cost
            if nd < dist[ni,nj]:
                dist[ni,nj]=nd
                heapq.heappush(hq,(nd,ni,nj))
    return float("inf")

def bilinear(U, rho, z, r, zz):
    ir = np.searchsorted(rho, r) - 1
    iz = np.searchsorted(z, zz) - 1
    ir = np.clip(ir, 0, len(rho)-2)
    iz = np.clip(iz, 0, len(z)-2)
    r1, r2 = rho[ir], rho[ir+1]
    z1, z2 = z[iz], z[iz+1]
    fr = 0 if r2==r1 else (r - r1)/(r2-r1)
    fz = 0 if z2==z1 else (zz - z1)/(z2-z1)
    v11 = U[ir, iz]
    v21 = U[ir+1, iz]
    v12 = U[ir, iz+1]
    v22 = U[ir+1, iz+1]
    return (1-fr)*(1-fz)*v11 + fr*(1-fz)*v21 + (1-fr)*fz*v12 + fr*fz*v22

def bezier_action(U, rho, z, E, z1, z2, rho1, rho2, n=400):
    P0 = np.array([0.0, z1])
    P3 = np.array([0.0, z2])
    P1 = np.array([rho1, z1 + (z2-z1)/3.0])
    P2 = np.array([rho2, z1 + 2.0*(z2-z1)/3.0])
    ts = np.linspace(0,1,n)
    pts = ((1-ts)**3)[:,None]*P0 + (3*(1-ts)**2*ts)[:,None]*P1 + (3*(1-ts)*ts**2)[:,None]*P2 + (ts**3)[:,None]*P3
    rs = np.clip(pts[:,0], rho[0], rho[-1]-1e-12)
    zs = np.clip(pts[:,1], z[0], z[-1]-1e-12)
    drs = np.diff(rs); dzs = np.diff(zs)
    ds = np.sqrt(drs*drs + dzs*dzs)
    rm = 0.5*(rs[:-1]+rs[1:])
    zm = 0.5*(zs[:-1]+zs[1:])
    w = np.array([math.sqrt(max(bilinear(U,rho,z,rm[i],zm[i]) - E, 0.0)) for i in range(len(ds))])
    return float(np.sum(w*ds))

def bezier_minimize(U, rho, z, E, z1, z2, rho_max, iters=25):
    rho1=rho2=0.0
    best=bezier_action(U,rho,z,E,z1,z2,rho1,rho2)
    step=rho_max/4.0
    for _ in range(iters):
        improved=False
        for which in [1,2]:
            for delta in [-step, step]:
                r1,r2=rho1,rho2
                if which==1: r1=float(np.clip(r1+delta,0,rho_max))
                else: r2=float(np.clip(r2+delta,0,rho_max))
                val=bezier_action(U,rho,z,E,z1,z2,r1,r2)
                if val<best:
                    best=val; rho1=r1; rho2=r2; improved=True
        if not improved:
            step*=0.5
            if step<rho_max/512:
                break
    return best, rho1, rho2

def run():
    # Inputs are taken from the packaged refined grid npz files.
    Ds=[6,12,18]
    levels=[("coarse",0.04,0.02), ("ref1",0.03,0.015), ("ref2",0.025,0.0125), ("fine",0.02,0.01)]
    rows=[]
    for D in Ds:
        grid=np.load(f"refined_U2D/U2D_refined_physical_gap_grid_D{D}.npz")
        a=float(grid["a"]); eps=float(grid["eps"]); m0=float(grid["m0"]); xi=float(grid["xi"])
        E=float(grid["E1"]); z1=float(grid["z1"]); z2=float(grid["z2"])
        rho_cut=float(grid["rho_cut"]); margin=float(grid["margin"])
        z_lo=float(grid["z"][0]); z_hi=float(grid["z"][-1])
        for name,dr,dz in levels:
            rho=np.arange(0,rho_cut+1e-12,dr)
            z=np.arange(z_lo,z_hi+1e-12,dz)
            U=compute_U2D(rho,z,D,a,eps,m0,xi)
            z1g,z2g=turning_points_axis(U[0,:],z,E)
            if z1g is None:
                z1g,z2g=z1,z2
            s=(0,int(np.argmin(np.abs(z-z1g))))
            g=(0,int(np.argmin(np.abs(z-z2g))))
            Sd=dijkstra_action(U,rho,z,E,s,g,neighbors=8)
            Sb,_,_=bezier_minimize(U,rho,z,E,z1g,z2g,rho_max=rho_cut,iters=22)
            rows.append({"D":D,"level":name,"dr":dr,"dz":dz,"h":max(dr,dz),"Smin_dijkstra8":Sd,"Smin_bezier":Sb})
    df=pd.DataFrame(rows)
    df.to_csv("todo3A_true_refinement_table.csv",index=False)
    # compute errors wrt fine
    fine=df[df.level=="fine"].set_index("D")
    df["rel_err_dijkstra8"]=df.apply(lambda r: abs(r.Smin_dijkstra8-fine.loc[r.D,"Smin_dijkstra8"])/fine.loc[r.D,"Smin_dijkstra8"], axis=1)
    df["rel_err_bezier"]=df.apply(lambda r: abs(r.Smin_bezier-fine.loc[r.D,"Smin_bezier"])/fine.loc[r.D,"Smin_bezier"], axis=1)
    df.to_csv("todo3A_true_refinement_with_errors.csv",index=False)
    # plots
    for col,out in [("rel_err_dijkstra8","true_refine_convergence_dijkstra8.png"),("rel_err_bezier","true_refine_convergence_bezier.png")]:
        plt.figure()
        for D in Ds:
            sub=df[df.D==D].sort_values("h")
            plt.plot(sub["h"], sub[col], marker="o", label=f"D={D}")
        plt.xscale("log"); plt.yscale("log")
        plt.xlabel("h=max(dr,dz)"); plt.ylabel(col)
        plt.grid(True, which="both", ls="--", alpha=0.4)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out, dpi=200)
        plt.close()
    print("Wrote todo3A_true_refinement_with_errors.csv and convergence plots.")
if __name__=="__main__":
    run()
