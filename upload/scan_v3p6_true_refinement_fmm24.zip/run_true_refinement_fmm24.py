#!/usr/bin/env python3
"""
run_true_refinement_fmm24.py

True refinement (NOT subsampling) convergence test for:
  (i) 24-neighbor graph shortest path (Dijkstra24)
  (ii) Eikonal Fast Marching Method (FMM) solving |∇T| = W, with W = sqrt(max(U - E, 0))

Uses analytic Omega for two-center smearing:
  Omega = 1 + a( 1/sqrt(r_+^2+eps^2) + 1/sqrt(r_-^2+eps^2) )
  ∇^2 Omega = a * [-3 eps^2 (r_+^2+eps^2)^(-5/2) + ...]
  U = m0^2 (Omega^2 - 1) + (1 - 6 xi) (∇^2 Omega / Omega)

Convergence is evaluated vs the finest grid ("fine") per D.

Note: This is the convergence of the *numerical proxy* S_min on a fixed (rho,z) window.
To guard against "off-axis escape", you should separately check rho_cut/window convergence (see todo3B_rho_window_check_D18.csv).
"""
import os, math, heapq
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def compute_U2D(rho, z, D, a, eps, m0, xi):
    R, Z = np.meshgrid(rho, z, indexing="ij")
    zp = Z - D/2.0
    zm = Z + D/2.0
    rp2 = R*R + zp*zp
    rm2 = R*R + zm*zm
    Omega = 1.0 + a*(1.0/np.sqrt(rp2 + eps*eps) + 1.0/np.sqrt(rm2 + eps*eps))
    lap_term = -3.0*(eps*eps)*((rp2 + eps*eps)**(-2.5) + (rm2 + eps*eps)**(-2.5))
    lap_Omega = a*lap_term
    U = (m0*m0)*(Omega*Omega - 1.0) + (1.0 - 6.0*xi)*(lap_Omega / Omega)
    return U.astype(np.float64)

def turning_points_axis(U_axis, z, E):
    f = U_axis - E
    s = np.sign(f); s[s==0]=1
    crossings=[]
    for i in range(len(z)-1):
        if s[i]*s[i+1] < 0:
            z0 = z[i] - f[i]*(z[i+1]-z[i])/(f[i+1]-f[i])
            crossings.append(z0)
    neg=[c for c in crossings if c<0]
    pos=[c for c in crossings if c>0]
    if not neg or not pos:
        return None, None
    return max(neg), min(pos)

def dijkstra24(W, rho, z, start, goal):
    Nr,Nz = W.shape
    offs=[(di,dj) for di in (-2,-1,0,1,2) for dj in (-2,-1,0,1,2) if not (di==0 and dj==0)]
    sr,sz=start; gr,gz=goal
    dist=np.full((Nr,Nz), np.inf, dtype=np.float64)
    dist[sr,sz]=0.0
    hq=[(0.0,sr,sz)]
    while hq:
        d,i,j=heapq.heappop(hq)
        if d!=dist[i,j]:
            continue
        if (i,j)==(gr,gz):
            return float(d)
        wi=W[i,j]
        for di,dj in offs:
            ni=i+di; nj=j+dj
            if ni<0 or ni>=Nr or nj<0 or nj>=Nz:
                continue
            ds=math.sqrt((rho[ni]-rho[i])**2 + (z[nj]-z[j])**2)
            nd=d + 0.5*(wi+W[ni,nj])*ds
            if nd < dist[ni,nj]:
                dist[ni,nj]=nd
                heapq.heappush(hq,(nd,ni,nj))
    return float("inf")

def fmm_eikonal(W, dr, dz, start, goal):
    Nr,Nz=W.shape
    FAR=0; TRIAL=1; KNOWN=2
    status=np.zeros((Nr,Nz), dtype=np.uint8)
    T=np.full((Nr,Nz), np.inf, dtype=np.float64)
    sr,sz=start; gr,gz=goal
    T[sr,sz]=0.0
    status[sr,sz]=KNOWN
    hq=[]

    def update(i,j):
        a=np.inf; b=np.inf
        if i>0 and status[i-1,j]==KNOWN: a=min(a, T[i-1,j])
        if i<Nr-1 and status[i+1,j]==KNOWN: a=min(a, T[i+1,j])
        if j>0 and status[i,j-1]==KNOWN: b=min(b, T[i,j-1])
        if j<Nz-1 and status[i,j+1]==KNOWN: b=min(b, T[i,j+1])
        w=float(W[i,j])
        if np.isinf(a) and np.isinf(b):
            return np.inf
        if w<=0.0:
            return float(min(a,b))
        cand=[]
        if not np.isinf(a): cand.append(a + w*dr)
        if not np.isinf(b): cand.append(b + w*dz)
        if np.isinf(a) or np.isinf(b):
            return float(min(cand)) if cand else np.inf
        A=1.0/(dr*dr) + 1.0/(dz*dz)
        B=-2.0*(a/(dr*dr) + b/(dz*dz))
        C=(a*a)/(dr*dr) + (b*b)/(dz*dz) - w*w
        disc=B*B - 4*A*C
        if disc<0.0:
            return float(min(cand))
        t=(-B + math.sqrt(disc))/(2*A)
        if t < max(a,b):
            return float(min(cand))
        return float(t)

    for di,dj in [(1,0),(-1,0),(0,1),(0,-1)]:
        ni=sr+di; nj=sz+dj
        if 0<=ni<Nr and 0<=nj<Nz and status[ni,nj]!=KNOWN:
            tt=update(ni,nj)
            if tt<np.inf:
                T[ni,nj]=tt
                status[ni,nj]=TRIAL
                heapq.heappush(hq,(tt,ni,nj))

    while hq:
        t,i,j=heapq.heappop(hq)
        if status[i,j]==KNOWN:
            continue
        if t!=T[i,j]:
            continue
        status[i,j]=KNOWN
        if (i,j)==(gr,gz):
            return float(t)
        for di,dj in [(1,0),(-1,0),(0,1),(0,-1)]:
            ni=i+di; nj=j+dj
            if 0<=ni<Nr and 0<=nj<Nz and status[ni,nj]!=KNOWN:
                tt=update(ni,nj)
                if tt < T[ni,nj]:
                    T[ni,nj]=tt
                    status[ni,nj]=TRIAL
                    heapq.heappush(hq,(tt,ni,nj))
    return float("inf")

def run(refined_grid_dir="refined_U2D", rho_cut=1.0, Ds=(6,12,18)):
    levels=[("coarse",0.04,0.02), ("mid",0.03,0.015), ("fine",0.02,0.01)]
    rows=[]
    for D in Ds:
        grid=np.load(os.path.join(refined_grid_dir, f"U2D_refined_physical_gap_grid_D{D}.npz"))
        a=float(grid["a"]); eps=float(grid["eps"]); m0=float(grid["m0"]); xi=float(grid["xi"])
        E=float(grid["E1"])
        z_fine=grid["z"].astype(np.float64)
        z_lo=float(z_fine[0]); z_hi=float(z_fine[-1])
        for lvl,dr,dz in levels:
            rho=np.arange(0, rho_cut+1e-12, dr)
            z=np.arange(z_lo, z_hi+1e-12, dz)
            U=compute_U2D(rho,z,D,a,eps,m0,xi)
            W=np.sqrt(np.maximum(U-E,0.0))
            z1g,z2g=turning_points_axis(U[0,:], z, E)
            if z1g is None:
                z1g=float(grid["z1"]); z2g=float(grid["z2"])
            start=(0,int(np.argmin(np.abs(z-z1g))))
            goal =(0,int(np.argmin(np.abs(z-z2g))))
            Sd=dijkstra24(W,rho,z,start,goal)
            Sf=fmm_eikonal(W,dr,dz,start,goal)
            rows.append(dict(D=D, rho_cut=rho_cut, level=lvl, dr=dr, dz=dz, h=max(dr,dz),
                             Nr=len(rho), Nz=len(z), z1=float(z1g), z2=float(z2g),
                             Smin_dijkstra24=Sd, Smin_fmm=Sf))
    df=pd.DataFrame(rows)
    fine=df[df.level=="fine"].set_index("D")
    df["rel_err_Smin_dijkstra24"]=df.apply(lambda r: abs(r.Smin_dijkstra24-fine.loc[r.D,"Smin_dijkstra24"])/fine.loc[r.D,"Smin_dijkstra24"], axis=1)
    df["rel_err_Smin_fmm"]=df.apply(lambda r: abs(r.Smin_fmm-fine.loc[r.D,"Smin_fmm"])/fine.loc[r.D,"Smin_fmm"], axis=1)
    df.to_csv("todo3B_true_refinement_fmm24_all_with_errors.csv", index=False)

    for col,out in [("rel_err_Smin_dijkstra24","true_refine_convergence_dijkstra24_all.png"),
                    ("rel_err_Smin_fmm","true_refine_convergence_fmm_all.png")]:
        plt.figure()
        for D in sorted(set(df.D)):
            sub=df[df.D==D].sort_values("h")
            plt.plot(sub["h"], sub[col], marker="o", label=f"D={D}")
        plt.xscale("log"); plt.yscale("log")
        plt.xlabel("h=max(dr,dz)")
        plt.ylabel(col)
        plt.grid(True, which="both", ls="--", alpha=0.4)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out, dpi=200)
        plt.close()

    print("Wrote: todo3B_true_refinement_fmm24_all_with_errors.csv and convergence plots.")

if __name__=="__main__":
    run()
