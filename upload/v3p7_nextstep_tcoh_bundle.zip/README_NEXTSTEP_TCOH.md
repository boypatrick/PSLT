# Next-step: Geometry-closed t_coh(D) (v3p7 base)

This bundle derives a geometry-closed coherence time:

t_coh(D) ≈ (2π/C_*) ω̄(D) exp(S_min(D))

- ω̄(D) is taken from axis-1D scan (n=1, physical_gap preset).
- S_min(D) is estimated from axis-1D WKB action Sz1(D) plus a small correction ΔS(D),
  calibrated against true-refinement 2D FMM24 results at D=6,12,18.
- The WKB matching constant C_* is calibrated from the paper unified table (D>=12):

C_* = mean[ ΔE * exp(S1) ]_(D>=12) = 1.82925565176562

## Files
- tcoh_geom_curve_axis1d.csv : D-grid (4..20 step 0.5) with omega1, Sz1, Smin_est, tcoh_geom
- Smin_Sz_anchor_correction.csv : (D=6,12,18) anchor differences used for ΔS fit
- deltaE_prefactor_check.csv : checks ΔE ≈ C_* exp(-Smin_est) against unified table rows
- tcoh_geom_log10_vs_D.png : quick visualization
- deltaE_vs_Smin_check.png : prefactor consistency plot
- apply_tcoh_geom_to_phase_grid.py : utility to add tcoh_geom columns to your phase_grid*.csv

## How to use
1) Put this folder contents next to your phase scan outputs.
2) Ensure `tcoh_geom_curve_axis1d.csv` is present.
3) Run:
   python apply_tcoh_geom_to_phase_grid.py

It will generate `phase_grid*_tcoh_geom.csv` with added columns.
