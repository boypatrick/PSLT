#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
apply_tcoh_geom_to_phase_grid.py

Drop-in utility:
- Looks for CSV files matching phase_grid*.csv in current directory.
- Adds geometry-closed coherence time columns based on D:
    Smin_est(D), omega1(D), tcoh_geom(D)
- Writes new CSV with suffix _tcoh_geom.csv

This does NOT recompute winners by itself (your Gamma/P_N logic may live elsewhere).
"""

import glob
import math
import pandas as pd
import numpy as np

C_STAR = 1.82925565176562
DELTA_S_INF = 0.0135035147807253016
C_OVER_D = 0.00441188797114587441

def deltaS(D: float) -> float:
    D=float(D)
    return float(DELTA_S_INF + C_OVER_D*(1.0/D))

CURVE_CSV = "tcoh_geom_curve_axis1d.csv"
curve = pd.read_csv(CURVE_CSV).set_index("D")
Ds = curve.index.values.astype(float)
omega1s = curve["omega1"].values.astype(float)
Sz1s = curve["Sz1"].values.astype(float)

def omega1_of(D):
    return float(np.interp(float(D), Ds, omega1s))

def Sz1_of(D):
    return float(np.interp(float(D), Ds, Sz1s))

def Smin_est_of(D):
    return Sz1_of(D) + deltaS(D)

def tcoh_geom_of(D):
    S = Smin_est_of(D)
    w = omega1_of(D)
    return (2*math.pi/C_STAR) * w * math.exp(S)

def main():
    files = sorted(set(glob.glob("phase_grid*.csv")))
    if not files:
        raise SystemExit("No phase_grid*.csv found in current directory.")
    for fn in files:
        df = pd.read_csv(fn)
        if "D" not in df.columns:
            print(f"[skip] {fn}: missing column 'D'")
            continue
        Dcol = df["D"].astype(float).values
        df["omega1_est"] = [omega1_of(d) for d in Dcol]
        df["Sz1_est"] = [Sz1_of(d) for d in Dcol]
        df["deltaS_corr"] = [deltaS(d) for d in Dcol]
        df["Smin_est"] = df["Sz1_est"] + df["deltaS_corr"]
        df["C_star"] = C_STAR
        df["tcoh_geom"] = [tcoh_geom_of(d) for d in Dcol]
        out = fn.replace(".csv","_tcoh_geom.csv")
        df.to_csv(out, index=False)
        print(f"[ok] wrote {out}")

if __name__ == "__main__":
    main()
